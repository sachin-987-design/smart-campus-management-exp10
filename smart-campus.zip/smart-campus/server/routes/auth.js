const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
router.post('/register', async (req,res)=>{
  try { const {name,email,password,role} = req.body; const exists = await User.findOne({email}); if(exists) return res.status(400).json({message:'Email already registered'}); const hash = await bcrypt.hash(password,10); const user = await User.create({name,email,password:hash,role}); res.status(201).json({message:'Registered successfully', user:{id:user._id,name:user.name,email:user.email,role:user.role}}); }
  catch(e){ res.status(500).json({message:e.message}); }
});
router.post('/login', async (req,res)=>{
  try { const {email,password} = req.body; const user = await User.findOne({email}); if(!user) return res.status(400).json({message:'Invalid credentials'}); const ok = await bcrypt.compare(password,user.password); if(!ok) return res.status(400).json({message:'Invalid credentials'}); const token = jwt.sign({id:user._id,role:user.role,name:user.name}, process.env.JWT_SECRET, {expiresIn:'7d'}); res.json({token,user:{id:user._id,name:user.name,email:user.email,role:user.role}}); }
  catch(e){ res.status(500).json({message:e.message}); }
});
module.exports = router;
